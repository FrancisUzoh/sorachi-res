
import React from 'react';
import ReactDOM from 'react-dom/client';
import { HelmetProvider } from 'react-helmet-async';
import { AtmosphereProvider } from './lib/atmosphere-context.tsx';
import App from './App';
import './index.css';

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <HelmetProvider>
      <AtmosphereProvider>
        <App />
      </AtmosphereProvider>
    </HelmetProvider>
  </React.StrictMode>
);
