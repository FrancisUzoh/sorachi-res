import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import Stripe from 'stripe';
import dotenv from 'dotenv';
import cors from 'cors';
import * as admin from 'firebase-admin';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Firebase Admin
let firebaseAdminApp: admin.app.App | null = null;

const getFirebaseAdmin = () => {
  if (!firebaseAdminApp) {
    // Read config to get project ID
    try {
      const configPath = path.resolve(__dirname, 'firebase-applet-config.json');
      const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
      
      firebaseAdminApp = admin.initializeApp({
        projectId: config.projectId,
      });
      console.log('Firebase Admin initialized with project:', config.projectId);
    } catch (error) {
      console.error('Error initializing Firebase Admin:', error);
      // Fallback or rethrow? Let's try to initialize with env if possible
      if (!admin.apps.length) {
        firebaseAdminApp = admin.initializeApp();
      } else {
        firebaseAdminApp = admin.app();
      }
    }
  }
  return firebaseAdminApp;
};

let stripeClient: Stripe | null = null;

const getStripe = () => {
  if (!stripeClient) {
    const key = process.env.STRIPE_SECRET_KEY;
    if (!key) {
      throw new Error('STRIPE_SECRET_KEY is not set in the environment variables.');
    }
    stripeClient = new Stripe(key);
  }
  return stripeClient;
};

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(cors());
  
  // Webhook needs raw body for signature verification
  app.post('/api/webhook', express.raw({ type: 'application/json' }), async (req, res) => {
    const sig = req.headers['stripe-signature'];
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

    let event;

    try {
      const stripe = getStripe();
      if (webhookSecret && sig) {
        event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
      } else {
        event = JSON.parse(req.body);
      }
    } catch (err: any) {
      console.error(`Webhook Error: ${err.message}`);
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    if (event?.type === 'checkout.session.completed') {
      const session = event.data.object as Stripe.Checkout.Session;
      const bookingId = session.metadata?.bookingId;

      if (bookingId) {
        console.log(`Payment successful for booking: ${bookingId}`);
        try {
          getFirebaseAdmin();
          const db = admin.firestore();
          await db.collection('bookings').doc(bookingId).update({
            depositPaid: true,
            status: 'confirmed'
          });
          console.log(`Successfully updated booking ${bookingId} to confirmed/paid`);
        } catch (error) {
          console.error('Error updating booking in Firestore:', error);
        }
      }
    }

    res.json({ received: true });
  });

  app.use(express.json());

  // API Routes
  app.get('/api/health', (req, res) => {
    console.log('[Server] Health check');
    res.json({ status: 'ok', time: new Date().toISOString() });
  });

  app.get('/api/ping', (req, res) => {
    console.log('[Server] Ping from', req.ip);
    res.json({ 
      message: 'pong', 
      timestamp: new Date().toISOString(),
      server: 'Sora Core Express Server'
    });
  });

  app.get('/api/test', (req, res) => {
    console.log('[Server] Test route reached');
    res.json({ message: 'API is reachable' });
  });

  // WordPress GraphQL Proxy to bypass CORS and handle Basic Auth
  app.post('/api/wordpress-proxy', async (req, res) => {
    let wpUrl = process.env.VITE_WORDPRESS_API_URL;
    
    // Override if pointing to old service or missing
    if (!wpUrl || wpUrl.includes('massive-paint.localsite.io')) {
      wpUrl = 'https://sorasuchi.ct.ws';
    }
    
    console.log(`WordPress Proxy: Using URL: ${wpUrl}`);

    const body = req.body || {};
    if (!body.query) {
      console.warn('WordPress Proxy: Received request with no query in body.');
    }

    // Normalize URL: If it doesn't contain 'graphql', assume it's the site root
    if (!wpUrl.toLowerCase().includes('graphql')) {
      wpUrl = wpUrl.endsWith('/') ? `${wpUrl}graphql` : `${wpUrl}/graphql`;
      console.log(`WordPress Proxy: URL normalized to ${wpUrl}`);
    }

    const authUser = process.env.WP_AUTH_USER;
    const authPass = process.env.WP_AUTH_PASS;
    
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    };

    if (authUser && authPass) {
      headers['Authorization'] = `Basic ${Buffer.from(`${authUser}:${authPass}`).toString('base64')}`;
    }

    const attempts: { url: string; status: number; method: string; error?: string }[] = [];

    const tryFetch = async (url: string, silent: boolean = false): Promise<Response | null> => {
      try {
        if (!silent) console.log(`WordPress Proxy: Connection attempt to ${url}...`);
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), silent ? 4000 : 8000); // Shorter timeout for fallbacks
        
        const response = await fetch(url, {
          method: 'POST',
          headers,
          body: JSON.stringify(body),
          signal: controller.signal,
        });
        
        clearTimeout(timeoutId);
        
        // If POST fails with 405 or 404, or any other error, log it
        if (!response.ok) {
          attempts.push({ url, status: response.status, method: 'POST' });
          if (!silent) console.warn(`WordPress Proxy: POST ${url} failed with status ${response.status}`);
          
          // Fallback: If it's a 405 (Method Not Allowed), many WP setups only allow GET for GraphQL
          if (response.status === 405 || response.status === 404) {
            const getUrl = new URL(url);
            if (body.query) getUrl.searchParams.append('query', body.query);
            if (body.variables) getUrl.searchParams.append('variables', JSON.stringify(body.variables));
            
            const getController = new AbortController();
            const getTimeoutId = setTimeout(() => getController.abort(), 5000);
            
            try {
              const getRes = await fetch(getUrl.toString(), {
                method: 'GET',
                headers: { 'Authorization': headers['Authorization'] || '' },
                signal: getController.signal,
              });
              clearTimeout(getTimeoutId);
              attempts.push({ url: getUrl.toString(), status: getRes.status, method: 'GET' });
              if (getRes.ok) return getRes;
            } catch (err: any) {
              clearTimeout(getTimeoutId);
              attempts.push({ url: getUrl.toString(), status: 0, method: 'GET', error: err.message });
            }
          }
        } else {
          attempts.push({ url, status: response.status, method: 'POST' });
          if (!silent) console.log(`WordPress Proxy: POST ${url} Success!`);
          return response;
        }
        
        return null;
      } catch (e: any) {
        if (!silent) console.error(`WordPress Proxy: Error fetching ${url}:`, e.message);
        attempts.push({ url, status: 0, method: 'ERROR', error: e.message });
        return null;
      }
    };

    // 1. Try primary URL
    let finalResponse = await tryFetch(wpUrl);

    // Check if we should return mock data (e.g., if it's a local URL that we know will fail in Cloud Run)
    const isLocalUrl = wpUrl.includes('localhost') || wpUrl.includes('127.0.0.1') || wpUrl.includes('.local') || wpUrl.includes('localsite.io');

    // 2. If failed, try fallbacks
    if (!finalResponse) {
      // If it's a local URL and it failed once with 404, don't waste time on fallbacks as the tunnel is likely dead
      if (isLocalUrl) {
        console.warn(`WordPress Proxy: URL ${wpUrl} is unreachable (likely an expired LocalWP Live Link). Falling back to mock data.`);
      } else {
        const urlObj = new URL(wpUrl);
        const baseUrl = `${urlObj.protocol}//${urlObj.host}`;
        const httpBaseUrl = `http://${urlObj.host}`;
        
        const fallbacks = [
          wpUrl.replace(/\/graphql\/?$/, '/?graphql'),
          wpUrl.replace(/\/graphql\/?$/, '/index.php?graphql'),
          `${baseUrl}/graphql`,
          `${baseUrl}/?graphql`,
          `${httpBaseUrl}/graphql`, // HTTP fallback
          `${httpBaseUrl}/?graphql`, // HTTP fallback
        ].filter(Boolean).filter(u => u !== wpUrl && !attempts.some(a => a.url === u)) as string[];

        for (const fallbackUrl of fallbacks) {
          finalResponse = await tryFetch(fallbackUrl, true); // Silent fallbacks
          if (finalResponse) break;
        }
      }
    }

    // If all failed, return mock data as a fallback to keep the app functional
    if (!finalResponse) {
      console.warn('WordPress Proxy: All connection attempts failed. Details:');
      console.table(attempts);
      console.warn('Returning premium mock content as fallback.');
      
      const mockData = {
        data: {
          dishes: {
            nodes: [
              {
                id: 'mock-1',
                title: 'The Imperial Omakase',
                menuItemDetails: {
                  price: '210',
                  description: 'A 22-course masterpiece that evolves with the tides. Our most exclusive journey.',
                  category: 'Omakase'
                }
              },
              {
                id: 'mock-2',
                title: 'Sora Signature Omakase',
                menuItemDetails: {
                  price: '165',
                  description: '15 courses of seasonal perfection, highlighting the best of Toyosu Market.',
                  category: 'Omakase'
                }
              },
              {
                id: 'mock-3',
                title: 'Bluefin Trio Selection',
                menuItemDetails: {
                  price: '85',
                  description: 'Akami, Chutoro, and Otoro aged for 14 days for optimal umami.',
                  category: 'Nigiri'
                }
              },
              {
                id: 'mock-4',
                title: 'A5 Wagyu Ishiyaki',
                menuItemDetails: {
                  price: '95',
                  description: 'Sizzling Miyazaki A5 Wagyu over volcanic stone with fresh wasabi.',
                  category: 'Premium'
                }
              }
            ]
          },
          restaurantSettings: {
            contactInfo: {
              address: '42 Loampit Vale, Lewisham, London SE13 7SN',
              phone: '+44 20 7946 0123',
              currentStatus: 'Open Today 12:00 – 23:00'
            }
          },
          menuItems: {
            nodes: [
              { id: 'm1', label: 'Home', url: '/', path: '/' },
              { id: 'm2', label: 'Menu', url: '/menu', path: '/menu' },
              { id: 'm3', label: 'Blog', url: '/blog', path: '/blog' },
              { id: 'm4', label: 'Premium', url: '/premium', path: '/premium' },
              { id: 'm5', label: 'About', url: '/about', path: '/about' }
            ]
          },
          posts: {
            nodes: [
              {
                id: 'p1',
                title: 'The Art of Omakase: A Journey Through Tradition',
                excerpt: 'Discover the philosophy behind our 22-course omakase experience...',
                date: new Date().toISOString(),
                slug: 'art-of-omakase',
                featuredImage: { node: { sourceUrl: 'https://images.unsplash.com/photo-1579871494447-9811cf80d66c?auto=format&fit=crop&q=80&w=1200' } }
              },
              {
                id: 'p2',
                title: 'Sourcing at Toyosu: The Heart of Sora',
                excerpt: 'Learn how our chefs select the finest fish every morning at 4 AM...',
                date: new Date(Date.now() - 86400000 * 2).toISOString(),
                slug: 'toyosu-sourcing',
                featuredImage: { node: { sourceUrl: 'https://images.unsplash.com/photo-1534422298391-e4f8c170db76?auto=format&fit=crop&q=80&w=1200' } }
              }
            ]
          }
        },
        _isMock: true,
        _notice: 'Using premium mock data. WordPress site unreachable.'
      };
      
      return res.json(mockData);
    }

    try {
      const data = await finalResponse.json();
      return res.json(data);
    } catch (e: any) {
      console.error('WordPress Proxy: JSON parse error', e.message);
      return res.status(500).json({ error: 'Invalid JSON from WordPress' });
    }
  });

  // Stripe Checkout Session
  app.post('/api/create-checkout-session', async (req, res) => {
    try {
      const stripe = getStripe();
      const { bookingId, amount, name, email } = req.body;

      if (!bookingId || amount === undefined || amount === null) {
        return res.status(400).json({ error: 'Missing booking details' });
      }

      // Use APP_URL from environment (provided by platform), fallback to VITE_APP_URL, then localhost
      const baseUrl = process.env.APP_URL || process.env.VITE_APP_URL || 'http://localhost:3000';
      // Ensure no trailing slash for consistency
      const sanitizedBaseUrl = baseUrl.endsWith('/') ? baseUrl.slice(0, -1) : baseUrl;

      const session = await stripe.checkout.sessions.create({
        payment_method_types: ['card'],
        line_items: [
          {
            price_data: {
              currency: 'gbp',
              product_data: {
                name: `Booking Deposit for ${name}`,
                description: `Booking ID: ${bookingId}`,
              },
              unit_amount: Math.round(amount * 100), // in pence
            },
            quantity: 1,
          },
        ],
        mode: 'payment',
        success_url: `${sanitizedBaseUrl}/dashboard?success=true&booking_id=${bookingId}`,
        cancel_url: `${sanitizedBaseUrl}/dashboard?canceled=true`,
        customer_email: email,
        metadata: {
          bookingId,
        },
      });

      res.json({ id: session.id, url: session.url });
    } catch (error: any) {
      console.error('Stripe error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Global Error Handler - Moved to end
  app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
    console.error('SERVER ERROR:', err);
    res.status(500).json({ error: 'Internal Server Error', details: err.message });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    console.log('Starting server in DEVELOPMENT mode');
    try {
      const vite = await createViteServer({
        server: { middlewareMode: true },
        appType: 'spa',
      });
      app.use(vite.middlewares);
      
      // Catch-all for development (Express 5 uses regex for wildcards)
      app.get(/^(?!\/api).*/, async (req, res, next) => {
        const url = req.originalUrl;
        try {
          const indexPath = path.resolve(__dirname, 'index.html');
          let html = fs.readFileSync(indexPath, 'utf-8');
          html = await vite.transformIndexHtml(url, html);
          res.status(200).set({ 'Content-Type': 'text/html' }).end(html);
        } catch (e) {
          next(e);
        }
      });
    } catch (e) {
      console.error('FAILED TO CREATE VITE SERVER:', e);
      process.exit(1);
    }
  } else {
    console.log('Starting server in PRODUCTION mode');
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get(/^(?!\/api).*/, (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  console.log('[Server] Initializing listeners...');
  app.listen(PORT, '0.0.0.0', () => {
    console.log('================================================');
    console.log(`🚀 SERVER RUNNING ON http://localhost:${PORT}`);
    console.log(`🌍 ACCESSIBLE ON http://0.0.0.0:${PORT}`);
    console.log('✅ API Routes: /api/health, /api/ping, /api/test, /api/wordpress-proxy');
    console.log('================================================');
  });
}

process.on('uncaughtException', (err) => {
  console.error('[UNCAUGHT EXCEPTION]:', err);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('[UNHANDLED REJECTION]:', reason);
});

startServer().catch(err => {
  console.error('CRITICAL SERVER STARTUP ERROR:', err);
});
